/*
 * Generated code, do not edit
 */
package com.minotauro.cleda.task.prop;

public class MTaskProp {

  private MTaskProp() {
    // Empty
  }

  public static final String ERROR_MSG = "errorMsg";
  public static final String ID = "id";
  public static final String LAST_DATE = "lastDate";
  public static final String LAST_DATE_MILLIS = "lastDateMillis";
  public static final String NEXT_DATE = "nextDate";
  public static final String NEXT_DATE_MILLIS = "nextDateMillis";
  public static final String PROG_DATE = "progDate";
  public static final String PROG_DATE_MILLIS = "progDateMillis";
  public static final String PROXY_ID = "proxyId";
  public static final String RETRY_MILIS = "retryMilis";
  public static final String RETRY_TIMES = "retryTimes";
  public static final String RETRY_TRIES = "retryTries";
  public static final String SCHED_ID = "schedId";
  public static final String STATUS = "status";
  public static final String SUSP_DATE = "suspDate";
  public static final String SUSP_DATE_MILLIS = "suspDateMillis";
  public static final String SYSTEM_ENTRY = "systemEntry";
}
