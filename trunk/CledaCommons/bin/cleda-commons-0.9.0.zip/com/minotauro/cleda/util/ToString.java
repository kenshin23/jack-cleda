/*
 * Created on 21/03/2008
 */
package com.minotauro.cleda.util;

/**
 * @author Demián Gutierrez
 */
public interface ToString<T> {

  public String toString(T val);
}
