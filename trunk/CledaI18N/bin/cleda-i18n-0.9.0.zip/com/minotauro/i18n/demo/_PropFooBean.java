/*
 * Generated code, do not edit
 */
package com.minotauro.i18n.demo;

public class _PropFooBean {

  private _PropFooBean() {
    // Empty
  }

  public static final String CAMEL_CASE = "camelCase";
  public static final String DESC = "desc";
  public static final String EMPTY = "empty";
  public static final String NAME = "name";
}
