/*
 * Created on 03/05/2006
 */
package com.minotauro.base.model;

/**
 * @author Alejandro Salas
 */
public interface MOrder {

  public int getOrder();

  public void setOrder(int order);
}
