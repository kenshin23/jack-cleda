/*
 * Created on 27/03/2006
 */
package com.minotauro.base.model;

/** 
 * @author Alejandro Salas 
 */
public interface MWithName {

  public String getName();
}
