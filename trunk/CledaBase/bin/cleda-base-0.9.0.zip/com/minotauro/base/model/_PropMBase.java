/*
 * Generated code, do not edit
 */
package com.minotauro.base.model;

public class _PropMBase {

  private _PropMBase() {
    // Empty
  }

  public static final String ID = "id";
  public static final String SYST_ENTRY = "systEntry";
}
