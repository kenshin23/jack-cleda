/*
 * Generated code, do not edit
 */
package com.minotauro.menu.model;

public class _PropMMenuMetaData {

  private _PropMMenuMetaData() {
    // Empty
  }

  public static final String ID = "id";
  public static final String KEY = "key";
  public static final String MENU_REF = "menuRef";
  public static final String PARENT = "parent";
  public static final String SYST_ENTRY = "systEntry";
  public static final String VAL = "val";
}
