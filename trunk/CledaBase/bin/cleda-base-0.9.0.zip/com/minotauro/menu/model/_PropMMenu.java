/*
 * Generated code, do not edit
 */
package com.minotauro.menu.model;

public class _PropMMenu {

  private _PropMMenu() {
    // Empty
  }

  public static final String HANDLER = "handler";
  public static final String I18N_CLS = "i18nCls";
  public static final String I18N_KEY = "i18nKey";
  public static final String ID = "id";
  public static final String MENU_META_DATA_MAP = "menuMetaDataMap";
  public static final String ORDER = "order";
  public static final String PRIV_REF = "privRef";
  public static final String ROLE_REF = "roleRef";
  public static final String ROUTE = "route";
  public static final String SCOPE = "scope";
  public static final String SYST_ENTRY = "systEntry";
  public static final String TYPE = "type";
}
