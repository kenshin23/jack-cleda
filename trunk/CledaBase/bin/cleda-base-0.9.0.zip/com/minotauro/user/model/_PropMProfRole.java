/*
 * Generated code, do not edit
 */
package com.minotauro.user.model;

public class _PropMProfRole {

  private _PropMProfRole() {
    // Empty
  }

  public static final String ID = "id";
  public static final String PROF_REF = "profRef";
  public static final String ROLE_REF = "roleRef";
  public static final String SYST_ENTRY = "systEntry";
}
