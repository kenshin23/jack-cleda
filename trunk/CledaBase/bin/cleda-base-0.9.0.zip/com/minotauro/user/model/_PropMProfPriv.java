/*
 * Generated code, do not edit
 */
package com.minotauro.user.model;

public class _PropMProfPriv {

  private _PropMProfPriv() {
    // Empty
  }

  public static final String ID = "id";
  public static final String PRIV_REF = "privRef";
  public static final String PROF_REF = "profRef";
  public static final String SYST_ENTRY = "systEntry";
}
