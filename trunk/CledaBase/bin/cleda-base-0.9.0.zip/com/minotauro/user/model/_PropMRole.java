/*
 * Generated code, do not edit
 */
package com.minotauro.user.model;

public class _PropMRole {

  private _PropMRole() {
    // Empty
  }

  public static final String DESCRIPTION = "description";
  public static final String ID = "id";
  public static final String NAME = "name";
  public static final String PROF_ROLE_LIST = "profRoleList";
  public static final String SYST_ENTRY = "systEntry";
}
