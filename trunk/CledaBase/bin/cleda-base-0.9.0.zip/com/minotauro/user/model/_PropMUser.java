/*
 * Generated code, do not edit
 */
package com.minotauro.user.model;

public class _PropMUser {

  private _PropMUser() {
    // Empty
  }

  public static final String COUNTRY = "country";
  public static final String ID = "id";
  public static final String LANGUAGE = "language";
  public static final String PASS = "pass";
  public static final String PRIV_LIST = "privList";
  public static final String ROLE_LIST = "roleList";
  public static final String SYST_ENTRY = "systEntry";
  public static final String USER = "user";
  public static final String USER_PROF_LIST = "userProfList";
  public static final String VARIANT = "variant";
}
