JAXB is used to parse XML files. Auto generated classes, can be updated from XSDs
files with the command line:

xjc -p com.minotauro.workflow.xml com/minotauro/workflow/xml/net-petri-def.xsd -d .

Run it from $PROJECT_HOME/src.
