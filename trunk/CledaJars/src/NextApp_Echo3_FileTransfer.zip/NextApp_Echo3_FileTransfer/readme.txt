----------------------------------------------------------------------
Echo File Transfer, version 3.0
Copyright (C) 2002-2007 NextApp, Inc.

http://www.nextapp.com/products/echo3/filetransfer

----------------------------------------------------------------------
Echo File Transfer is licensed under the Mozilla Public License.
Please see the files in the /Licensing folder for more information.

----------------------------------------------------------------------
This archive/package contains the following directory structure:

/SourceCode         - Provides the source code of the framework.  

/BinaryLibraries    - Provides binary versions of the Echo File Transfer libraries.

/BinaryApplications - Contains binary test and example applications,
                      packages as Web Archives (WAR files).

/Licensing          - Contains licensing information.
                      
----------------------------------------------------------------------
Please feel free to contact NextApp with any questions regarding Echo:

NextApp, Inc.                  http://www.nextapp.com       
2549-B Eastbluff Drive #201    echo@nextapp.com
Newport Beach, CA 92660
USA        

TEL: +1.949.340.2097
